*********************************************************************************
Flash version of Stock chart is not being developed further.
You might want to check JavaScript version of Stock chart which is more advanced,
doesn't require plug-in and can be viewed on iPad and all modern browsers.
*********************************************************************************
If you still want to use flash version, you might want to check:

visual editor: http://extra.amcharts.com/editor/

documentation: http://www.amcharts.com/docs/

support  forums: http://www.amcharts.com/forum/
********************************************************************************* 